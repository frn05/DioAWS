# Arquitetura AWS — EC2 + EBS

## Visão Geral
Este diagrama representa uma arquitetura básica na AWS utilizando:

- VPC (10.0.0.0/16)
- Subnet Pública (10.0.1.0/24)
- Subnet Privada (10.0.2.0/24)
- Internet Gateway
- Security Group
- Instâncias EC2
- Volumes EBS
- Snapshots EBS
- IAM Role

## Estrutura da Arquitetura

### AWS Cloud
Contém todos os recursos da infraestrutura.

### VPC
Rede isolada com o bloco CIDR 10.0.0.0/16.

### Subnet Pública
Hospeda recursos acessíveis externamente.

### Internet Gateway
Permite comunicação entre a VPC e a Internet.

### Security Group
Controla o tráfego de entrada e saída.
Portas liberadas:
- 22 (SSH)
- 80 (HTTP)
- 443 (HTTPS)

### EC2 Instance (t2.micro)
Servidor baseado em Amazon Linux 2.

Volumes associados:
- Root (OS): 8 GB gp2
- Dados: 100 GB gp3

### EC2 Instance (t3.medium)
Servidor para Backend ou Aplicação.

Volumes associados:
- Root (OS): 8 GB gp2
- Banco de Dados: 500 GB io1

### Comunicação Interna
A instância Backend/App pode se comunicar internamente com outros recursos através da rede privada.

### EBS Snapshot
Utilizado para backup dos volumes EBS.

### IAM Role
Permite que as instâncias EC2 assumam permissões sem necessidade de armazenar credenciais.

## Fluxo de Funcionamento

1. Usuários acessam a aplicação através da Internet.
2. O tráfego entra pelo Internet Gateway.
3. O Security Group valida as portas permitidas.
4. A instância EC2 processa as requisições.
5. Os dados são armazenados em volumes EBS.
6. Snapshots são criados para backup e recuperação.
7. A IAM Role fornece permissões seguras para acesso a serviços AWS.

## Arquivos

- arquitetura-ec2-ebs.drawio → Diagrama editável.
- README.md → Documentação da arquitetura.
